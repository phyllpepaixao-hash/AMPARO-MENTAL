# Entre — Um próximo passo, no seu ritmo.

**Entre** é um aplicativo web progressivo de apoio ao bem-estar emocional, projetado em português brasileiro com foco em acolhimento, privacidade rigorosa, segurança clínica e clareza no momento presente. O app não substitui psicoterapia, psiquiatria ou atendimento médico de emergência, mas atua como um companheiro gentil para ajudar adultos a atravessarem momentos de sobrecarga, ansiedade, estresse ou cansaço através de pequenos passos seguros e viáveis (2 a 10 minutos).

---

## 🌟 Principais Recursos

1. **Check-in Emocional Sem Julgamentos:** Registro diário de humor, energia e necessidades emocionais, sem diagnósticos automáticos.
2. **Chat de Escuta com IA (Gemini Server-Side):** Assistência empática baseada no modelo `gemini-3.8-flash`, com diretrizes clínicas estritas (recusa de diagnósticos, recusa de conselhos de medicação e interceptador determinístico de crises).
3. **Mecanismo de Segurança e Crises (CVV / SAMU / SOS):** Interceptação imediata de termos de risco, exibindo contatos de emergência verificados no Brasil (CVV 188, SAMU 192) e opções de preparação de mensagens voluntárias para pessoas de confiança.
4. **Próximo Passo Prático:** Sugestões acionáveis e realistas para sair do paralisante "tudo ou nada".
5. **Diário local com bloqueio visual opcional:** entradas armazenadas no `localStorage`; o PIN é armazenado como hash nas novas configurações, mas o conteúdo do diário não é criptografado. Não use como cofre para informações extremamente sensíveis.
6. **Paisagens Sonoras Offline (Web Audio API):** Síntese em tempo real de Chuva Suave, Ruído Marrom, Ondas do Mar e Tom Zen 432Hz sem downloads pesados.
7. **Ritual de Desaceleração Noturna:** Ferramentas para soltar o dia, avaliar a bateria de energia e induzir ao sono com ruído marrom.
8. **Preparação para Terapia e Consultas:** Organização de resumos semanais de check-ins e dúvidas para levar ao profissional de saúde.
9. **Transparência e LGPD:** Exportação e restauração completa de dados em JSON, modo visitante sem cadastro obrigatório, além de controles de acessibilidade (Modo Baixo Estímulo e Redução de Movimento).

---

## 🛠️ Tecnologias Utilizadas

- **Frontend:** React 19, TypeScript, Tailwind CSS (v4), Lucide React.
- **Backend:** Node.js, Express, TypeScript (`tsx`), `@google/genai` (v2.4.0).
- **Áudio:** Web Audio API (geração procedural offline).
- **Armazenamento:** `localStorage` e `sessionStorage`. Esses mecanismos não criptografam automaticamente os dados; o diário permanece acessível a alguém com acesso ao perfil do navegador. O chat pode transmitir mensagens ao servidor e ao provedor de IA configurado.

---

## 📋 Pré-requisitos

- Node.js (versão 18 ou superior recomendada)
- npm ou yarn

---

## 🚀 Instalação e Execução Local

1. Clone o repositório ou abra o projeto no ambiente AI Studio.
2. Instale as dependências:
   ```bash
   npm install
   ```
3. Configure as variáveis de ambiente baseando-se no arquivo `.env.example`:
   ```bash
   cp .env.example .env
   ```
   Adicione sua chave da API Gemini na variável `GEMINI_API_KEY` (ou configure no painel Secrets do AI Studio).
4. Inicie o servidor de desenvolvimento:
   ```bash
   npm run dev
   ```
   O aplicativo estará disponível em `http://localhost:3000`.

---

## 📦 Compilação e Produção

Para compilar o aplicativo para produção:
```bash
npm run build
```

Para iniciar o servidor em modo de produção:
```bash
npm start
```

---

## 🧪 Testes e Verificação

Para executar a verificação de tipos TypeScript e o linter:
```bash
npm run lint
```

---

## 🔒 Privacidade, LGPD e Limitações

- **Armazenamento Local:** Todos os dados de check-in, diário e preferências ficam armazenados exclusivamente no dispositivo do usuário. Nenhum dado sensível é retido em servidores em nuvem.
- **IA e Limitações:** As chamadas de IA passam pelo backend Express para proteger a chave da API. O modelo está instruído estritamente a não realizar diagnósticos, não prescrever medicamentos e direcionar casos agudos para serviços humanos de emergência.
- **Modo Visitante:** O aplicativo é totalmente funcional sem exigir criação de conta ou login em servidores externos.


## Refinamentos de EntrePlay

- Favoritos persistidos localmente e filtrados por IDs válidos.
- Quebra-cabeça embaralhado por movimentos legais, garantindo que o tabuleiro gerado seja solucionável.
- Jardim com recompensa apenas quando uma planta avança de estágio e limite de 12 plantas.
- Endpoint de chat com limite de tamanho de mensagem, histórico sanitizado e uma camada adicional de resposta de segurança para frases de risco explícitas. Essa camada não substitui avaliação humana nem garante detecção de todos os casos.
- PIN do diário armazenado como hash nas novas configurações; o PIN é apenas um bloqueio visual e não criptografa as entradas do diário. PINs legados podem continuar armazenados em texto até que o usuário configure um novo PIN.

## Verificação

A compilação de produção e o verificador TypeScript precisam ser executados em um ambiente com dependências instaladas (`npm install`, `npm run lint`, `npm run build`). A instalação de dependências não foi concluída neste ambiente, portanto não declare esta versão compilada ou validada em execução.
