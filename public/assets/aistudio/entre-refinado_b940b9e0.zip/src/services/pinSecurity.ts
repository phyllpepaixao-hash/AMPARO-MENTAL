/** Hashes the diary PIN so the raw code is not stored in localStorage.
 * This is not encryption of diary entries; local browser storage remains accessible
 * to someone with access to the browser profile or developer tools.
 */
export async function hashDiaryPin(pin: string): Promise<string> {
  if (!globalThis.crypto?.subtle) {
    throw new Error('Este navegador não oferece criptografia segura neste contexto. Use HTTPS ou desative o PIN.');
  }
  const bytes = new TextEncoder().encode(pin);
  const digest = await globalThis.crypto.subtle.digest('SHA-256', bytes);
  const hex = Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, '0')).join('');
  return `sha256:${hex}`;
}

export async function verifyDiaryPin(input: string, stored: string | null | undefined): Promise<boolean> {
  if (!stored) return false;
  // Legacy compatibility for PINs saved by older versions. Users should save a new PIN
  // to migrate away from plaintext storage.
  if (!stored.startsWith('sha256:')) return input === stored;
  return (await hashDiaryPin(input)) === stored;
}
