import React, { useState, useEffect } from 'react';
import { ArrowLeft, Wind, Sparkles, RefreshCw } from 'lucide-react';

interface BreathingBubblesGameProps {
  onBack: () => void;
}

export const BreathingBubblesGame: React.FC<BreathingBubblesGameProps> = ({ onBack }) => {
  const [phase, setPhase] = useState<'idle' | 'inhale' | 'exhale'>('idle');
  const [instruction, setInstruction] = useState('Toque em "Iniciar Respiração" ou toque nas bolhas abaixo.');
  const [secondsLeft, setSecondsLeft] = useState(0);
  const [poppedCount, setPoppedCount] = useState(0);

  useEffect(() => {
    let timer: any;
    if (phase === 'inhale') {
      setInstruction('Inspire suavemente, apenas se for confortável...');
      setSecondsLeft(3);
      timer = setTimeout(() => setPhase('exhale'), 3000);
    } else if (phase === 'exhale') {
      setInstruction('Expire com suavidade, sem forçar...');
      setSecondsLeft(4);
      timer = setTimeout(() => setPhase('inhale'), 4000);
    }
    return () => clearTimeout(timer);
  }, [phase]);

  const handleStart = () => {
    setPhase('inhale');
  };

  const handleStop = () => {
    setPhase('idle');
    setInstruction('Sessão pausada. Respire no seu próprio ritmo.');
  };

  const handlePopBubble = () => {
    setPoppedCount(prev => prev + 1);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 text-xs font-medium text-slate-300 bg-slate-900 border border-slate-800 hover:bg-slate-800 py-2 px-3 rounded-xl transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Voltar ao EntrePlay</span>
        </button>
        <div className="flex items-center gap-2 bg-teal-950/80 border border-teal-800/60 px-3 py-1.5 rounded-xl text-teal-300 text-xs font-semibold">
          <Sparkles className="w-4 h-4 text-teal-400" />
          <span>Bolhas estouradas: {poppedCount}</span>
        </div>
      </div>

      <div className="bg-gradient-to-br from-slate-900/90 via-slate-900/60 to-teal-950/40 border border-slate-800/80 p-6 rounded-3xl shadow-xl text-center space-y-4">
        <div className="w-14 h-14 bg-teal-500/10 border border-teal-500/30 rounded-2xl mx-auto flex items-center justify-center text-teal-300 text-2xl">
          🫧
        </div>
        <h2 className="text-xl font-bold font-serif text-slate-100">Bolhas de Respiro</h2>
        <p className="text-sm text-slate-300 max-w-md mx-auto">
          Acompanhe a bolha central se isso for confortável ou estoure bolhas flutuantes. Você pode parar ou respirar naturalmente a qualquer momento.
        </p>

        {/* Central Breathing Bubble */}
        <div className="py-8 flex flex-col items-center justify-center relative">
          <div className={`w-40 h-40 rounded-full border-4 border-teal-400/60 bg-gradient-to-br from-teal-400/20 via-sky-500/15 to-indigo-600/20 flex flex-col items-center justify-center shadow-2xl transition-all duration-1000 ${
            phase === 'inhale' ? 'scale-110 bg-teal-400/30 motion-reduce:scale-100' : phase === 'exhale' ? 'scale-95 opacity-90 motion-reduce:scale-100' : 'scale-100'
          }`}>
            <Wind className="w-8 h-8 text-teal-300 mb-1 animate-pulse" />
            <span className="text-xs font-bold text-teal-200 uppercase tracking-wider">{phase === 'idle' ? 'Pronto' : phase === 'inhale' ? 'Inspire' : 'Expire'}</span>
            {phase !== 'idle' && <span className="text-sm font-mono text-white mt-0.5">no seu ritmo</span>}
          </div>

          <p className="text-sm font-medium text-teal-300 mt-6">{instruction}</p>
        </div>

        <div className="flex justify-center gap-3">
          {phase === 'idle' ? (
            <button
              onClick={handleStart}
              className="px-6 py-2.5 rounded-xl text-sm font-semibold bg-teal-600 hover:bg-teal-500 text-white shadow-lg transition-all"
            >
              Iniciar Respiração Guiada
            </button>
          ) : (
            <button
              onClick={handleStop}
              className="px-6 py-2.5 rounded-xl text-sm font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-all"
            >
              Pausar Respiração
            </button>
          )}
        </div>
      </div>

      {/* Floating Pop Bubbles */}
      <div className="bg-slate-900/60 border border-slate-800 p-5 rounded-2xl text-center space-y-3">
        <h3 className="text-sm font-semibold text-slate-200">Toque nas bolhas para estourá-las com leveza</h3>
        <div className="flex flex-wrap justify-center gap-3 py-2">
          {[1, 2, 3, 4, 5, 6, 7, 8].map(i => (
            <button
              key={i}
              onClick={handlePopBubble}
              className="w-12 h-12 rounded-full bg-teal-500/10 hover:bg-teal-400/30 border border-teal-400/40 flex items-center justify-center text-teal-300 text-xs shadow hover:scale-110 transition-all animate-bounce"
              style={{ animationDuration: `${2 + (i % 3)}s` }}
            >
              🫧
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
